import express from "express";
import morgan from "morgan";
const cors = require('cors');
// Routes
import proyectoRoutes from "./routes/proyecto.routes";

const app = express();

//settings
app.set("port", 4000);

//Middlewares
app.use(morgan("dev"));
app.use(express.json());
app.use(cors());

//Routes
app.use("/api/proyecto",proyectoRoutes);
export default app;