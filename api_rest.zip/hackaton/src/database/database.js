import mysql from "promise-mysql";
import config_db from "./../config";

const connection = mysql.createConnection({
    host: 'localhost',
    database: 'recetas',
    user: 'root',
    password:'bfCm4n/BVD2t2FYU'
});

const getConnection = () =>{
    return connection;
};

module.exports = {
    getConnection
}
