import {Router} from "express";
import {methods as recetaController} from "./../controllers/proyecto.principal";

const router = Router();

router.post("/", recetaController.guardarReceta);
router.get("/recetas-guardadas", recetaController.getReceta);
router.delete('/:id', recetaController.deleteReceta);

export default router;