import { getConnection } from "../database/database";

const guardarReceta = async (req, res) => {
    try{
        const values = req.body;
        console.log(values);
        const connection = await getConnection();
        await connection.query(`INSERT INTO recetas_guardadas (Nombre, Receta) VALUES ('${values.platillo}', '${values.receta}')`);
        res.json("Receta guardada");
    }catch(err){
        res.status(500);
        res.send(err.message);
    }    
};

const getReceta = async (req, res) => {
    try{
    const connection = await getConnection();
    const result = await connection.query("SELECT * FROM recetas_guardadas");
    res.json(result);
    console.log(result);
    }catch(err){
        res.status(500);
        res.send(err.message);
    }
};

const deleteReceta = async (req, res) => {
    try {
        const connection = await getConnection();
        const id = req.params.id;
        console.log(id);	
        const result = await connection.query("DELETE FROM recetas_guardadas WHERE ID = ?", [id]); // Pasa el ID como un arreglo de parámetros
        res.json(result);
        console.log(result);
    } catch (err) {
        res.status(500);
        res.send(err.message);
    }
};

export const methods = {
    guardarReceta,
    getReceta,
    deleteReceta
};

